export const environment = {
  production: true,
  apiKey: '7b5d0d2f240b41759f0ab56f9ddb06c7',
  apiUrl: 'https://newsapi.org/v2'
};
